

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;
import de.umass.lastfm.*;
import java.io.*;
import org.json.JSONObject;
import java.io.InputStreamReader;

/**
 * Servlet implementation class LastFMServlet
 */
@WebServlet("/LastFMServlet")
public class LastFMServlet extends HttpServlet {
    private final String apiKey = "3ea42a75c883b4c2b6ce046f33b333ac"; 

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	   response.setContentType("text/html");
    	
    	
    	
    	StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }

        // Parse the JSON data
        JSONObject jsonData = new JSONObject(sb.toString());
        String genre1 = jsonData.getString("Genre1");
        String genre2 = jsonData.getString("Genre2");
        String genre3 = jsonData.getString("Genre3");
        String genre4 = jsonData.getString("Genre4");
        String genre5 = jsonData.getString("Genre5");
                              
        System.out.println(genre1);   
        System.out.println(genre2); 
        System.out.println(genre3); 
        System.out.println(genre4); 
        System.out.println(genre5); 
        
        
        
        
    	
       
        PrintWriter out = response.getWriter();

        // Create a list of maps to simulate the ResultSet
		List<Map<String, String>> dummyResults = new ArrayList<>();
		Map<String, String> row1 = new HashMap<>();
		row1.put("genreName", genre1);
		dummyResults.add(row1);

		Map<String, String> row2 = new HashMap<>();
		row2.put("genreName", genre2);
		dummyResults.add(row2);
		
		Map<String, String> row3 = new HashMap<>();
		row3.put("genreName", genre3);
		dummyResults.add(row3);
		
		Map<String, String> row4 = new HashMap<>();
		row4.put("genreName", genre4);
		dummyResults.add(row4);
		
		Map<String, String> row5 = new HashMap<>();
		row5.put("genreName", genre5);
		dummyResults.add(row5);
		
		out.println("<!DOCTYPE html>");
		out.println("<html lang='en'>");
		out.println("<head>");
		out.println("<meta charset='UTF-8'>");
		out.println("<meta http-equiv=\"refresh\"content=\"10\">");
		out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
		out.println("<link rel='stylesheet' type='text/css' href='lastfmstyles.css'>");
		out.println("<style type='text/css'>");
		out.println(" @import url('https://fonts.googleapis.com/css2?family=Allerta+Stencil&display=swap');");
		out.println("</style>");
		out.println("<title>Top Tracks</title>");
	
		out.println("</head>");
		out.println("<body>");
		out.println("<div class='container'>");
		out.println("<header><h1>Here are your top recommended songs!</h1></header>");
		out.println("<main>");

       // Iterate over the dummy results as if it were a ResultSet
		for (Map<String, String> dummyRow : dummyResults) {
		    String genre = dummyRow.get("genreName");
		    Random random = new Random();
		    // Simulate the topTracks collection
		    Collection<Track> topTracks = Tag.getTopTracks(genre, apiKey);
		    
		 // Convert Collection to List and shuffle it to randomize
		    List<Track> topTracksLIST = new ArrayList<>(topTracks);
		    Collections.shuffle(topTracksLIST);
		   
		    out.println("<h2>" + genre + "</h2>");
		    out.println("<ul class='song-list'>");
		   
		 
		    // Iterate through the first three elements of the shuffled list
		    for (int i = 0; i < Math.min(3, topTracksLIST.size()); i++) {
		        Track track = topTracksLIST.get(i);
		        out.println("<li class='song-details'>");
		        out.println("<span>'" + track.getName() + "' by " + track.getArtist() + "</span>");
		        out.println("</li>");
		    }

		    out.println("</ul>");
		}

		out.println("</main>");
		out.println("<footer>Powered by Last.fm</footer>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
    }
}
