
var ws;
var chatBox = document.getElementById('chat-display');
window.onload = initWebSocket;


function initWebSocket() {
    ws = new WebSocket('ws://localhost:12345'); // WebSocket URL

    ws.onmessage = function(event) {
        var message = event.data;
        chatBox.innerHTML += '<div>' + message + '</div>';
        chatBox.scrollTop = chatBox.scrollHeight;
    };

    ws.onclose = function() {
        console.log('Connection closed!');
        setTimeout(initWebSocket, 1000);
    };
}

function postComment() {
	
	
	const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('username');
    

	var singer = document.getElementById('singer-input').value.trim();
    var song = document.getElementById('song-input').value.trim();
    var comment = document.getElementById('comment-input').value.trim();
	// Validation
    if (singer == '' || comment == '') {
        alert('Please enter both a musician and a comment.');
        return;
    }
    if (song != ''){
		ws.send('(' + username +') ' + song + ' by ' + singer + ': ' + comment);
	}
	else{
		ws.send('(' + username +') ' + singer + ': ' + comment);
	}
    document.getElementById('singer-input').value = '';
    document.getElementById('song-input').value = '';
    document.getElementById('comment-input').value = '';
}
