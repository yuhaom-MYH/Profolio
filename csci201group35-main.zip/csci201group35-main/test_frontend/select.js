document.addEventListener('DOMContentLoaded', function() {
    const selectedGenres = new Set();

    document.querySelectorAll('.genre').forEach(genreButton => {
        genreButton.addEventListener('click', function() {
            const genre = this.getAttribute('data-genre');
            if (selectedGenres.has(genre)) {
                selectedGenres.delete(genre);
                this.classList.remove('selected');
            } else {
                selectedGenres.add(genre);
                this.classList.add('selected');
            }
        });
    });

    document.getElementById('next-button').addEventListener('click', function() {
        const username = 'username'; // Replace with logic to get the actual username
        const selectedGenresArray = Array.from(selectedGenres);

        fetch('/submit-genres', { // Replace with your actual endpoint
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, genres: selectedGenresArray })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            window.location.href = 'home.html'; // Redirect to the home page
        })
        .catch(error => {
            console.error('There has been a problem with your fetch operation:', error);
        });
    });
});
