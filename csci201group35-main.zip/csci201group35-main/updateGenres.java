import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/updateGenres")
public class updateGenres extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");

        // Read the JSON data from the request body
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }

        // Parse the JSON data using Gson
        Gson gson = new Gson();
        JsonObject jsonInput = gson.fromJson(sb.toString(), JsonObject.class);
        JsonArray genresArray = jsonInput.getAsJsonArray("genres");

        // Extract other parameters from the query string
        String username = request.getParameter("email");
        String password = request.getParameter("password");

        // Your business logic here...
        
        // Example: Print received data
        System.out.println("Received Genres: " + genresArray);
        System.out.println("Received Username: " + username);
        System.out.println("Received Password: " + password);
        JsonObject jsonResponse = new JsonObject();
        
        
        String SQLurl = "jdbc:mysql://localhost:3306/audio-avenue";
        String SQLuser = "root";
        String SQLpassword = "Roadlesst1!";
        
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        try (
        		
        	Connection connection = DriverManager.getConnection(SQLurl, SQLuser, SQLpassword);
             PrintWriter out = response.getWriter()) {

            // Prepare SQL query
            String sqlQuery = "UPDATE UserTable SET Genre1 = ?, Genre2 = ?, Genre3 = ?, Genre4 = ?, Genre5 = ? WHERE UserName = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(6, username);
                preparedStatement.setString(1, genresArray.get(0).toString().substring(1, (genresArray.get(0).toString().length())-1));
                preparedStatement.setString(2, genresArray.get(1).toString().substring(1, (genresArray.get(1).toString().length())-1));
                preparedStatement.setString(3, genresArray.get(2).toString().substring(1, (genresArray.get(2).toString().length())-1));
                preparedStatement.setString(4, genresArray.get(3).toString().substring(1, (genresArray.get(3).toString().length())-1));
                preparedStatement.setString(5, genresArray.get(4).toString().substring(1, (genresArray.get(4).toString().length())-1));

                // Execute query
                
                	
                	
                	int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        // Update successful
                        out.print("Success");
                        jsonResponse.addProperty("status", "Success");
                        response.getWriter().write(jsonResponse.toString());
                    } else {
                        // No rows were updated (username not found)
                        out.print("Failed");
                        jsonResponse.addProperty("status", "Failed");
                        response.getWriter().write(jsonResponse.toString());
                    }
                
            } 
            catch (SQLException e) {
                out.println("Update execution failed! Error: " + e.getMessage());
            }

        } catch (SQLException e) {
            throw new ServletException("Connection failed! Error: " + e.getMessage());
        }
        
        
        
        

        // Example: Sending a response
        
       
    }
}