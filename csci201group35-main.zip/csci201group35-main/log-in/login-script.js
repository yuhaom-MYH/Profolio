document.getElementById('next').addEventListener('click', function() {
    var email = document.getElementById('email').value;
    // Perform validation or proceed to the next step
    console.log('Email entered: ' + email);
});

document.getElementById('google-sign-in').addEventListener('click', function() {
    // Integrate Google Sign-In functionality
    console.log('Google Sign-In clicked');
});
