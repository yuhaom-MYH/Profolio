document.getElementById('mainhome').addEventListener('click', function() {
    window.location.href = 'mainhome.html';
});

