document.getElementById('login').addEventListener('click', function() {
    window.location.href = 'login.html';
});

document.getElementById('signup').addEventListener('click', function() {
    window.location.href = 'signup.html';
});
