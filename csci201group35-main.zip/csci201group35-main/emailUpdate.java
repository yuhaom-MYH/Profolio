import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/EmailServlet")
public class emailUpdate extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	//System.out.println("ENTERED SERVLET");
        response.setContentType("text/html;charset=UTF-8");
      
        // JDBC URL, username, and password of MySQL server
        String url = "jdbc:mysql://localhost:3306/audio-avenue";
        String user = "root";
        String password = "Roadlesst1!";

        // Get the username and password from the HTML form
        String email = request.getParameter("email");
       // String username = "Alex@gmail.com";
        String passwordInput = request.getParameter("password");
        String newEmail = request.getParameter("new");
        
        //System.out.println(username);
        //System.out.println(passwordInput);
        //System.out.println(newPassword);
       // String passwordInput = "123";
       // System.out.println(username);
        //System.out.println(passwordInput);
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        try (
        		
        		Connection connection = DriverManager.getConnection(url, user, password);
             PrintWriter out = response.getWriter()) {

            // Prepare SQL query
            String sqlQuery = "UPDATE UserTable SET UserName = ? WHERE UserName = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(1, newEmail);
                preparedStatement.setString(2, email);
                int rowsAffected;
                // Execute query
               rowsAffected = preparedStatement.executeUpdate(); 
               			
               if(rowsAffected > 0) {
                        // Successful login
                        out.print("Success");
               }
               else {
            	   out.print("Failed");
               }
                   
          
        } catch (SQLException e) {
            throw new ServletException("Connection failed! Error: " + e.getMessage());
        }
    } catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
}
}