
import com.google.gson.Gson; 
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.*;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.io.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@WebServlet(urlPatterns = "/your-servlet-url")
public class servlet extends HttpServlet {
	
	

     public void doGet(HttpServletRequest request1, HttpServletResponse response1) throws IOException {
        response1.setContentType("application/json");
        response1.setCharacterEncoding("UTF-8");
        List<SearchResults> results = new ArrayList<SearchResults>();
        
        
        List<String> genres = new ArrayList<String>();
        //***** THIS IS DUMMY CODE FILLING THE ARRAY FOR TESTING *****//
       
        //***** THIS IS DUMMY CODE FILLING THE ARRAY FOR TESTING *****//
        

        
        //**** ACTUAL REQUEST CODE ****//
      
        String genre1 = request1.getParameter("genre1");
        String genre2 = request1.getParameter("genre2");
        String genre3 = request1.getParameter("genre3");
        String genre4 = request1.getParameter("genre4");
        String genre5 = request1.getParameter("genre5");
        
        genres.add(genre1);
        genres.add(genre2);
        genres.add(genre3);
        genres.add(genre4);
        genres.add(genre5);
        
        //**** ACTUAL REQUEST CODE ****//
        
        for(String genre : genres) {
        	try {
        		String apiKey = "cefc2dc64b440af3b8426150ecd70939";
                String apiUrl = "http://ws.audioscrobbler.com/2.0/?method=tag.gettoptracks&tag=" + genre +
                                "&api_key=" + apiKey + "&format=json&limit=100";


                try {
                
                    URI uri = new URI(apiUrl);
                    HttpClient client = HttpClient.newHttpClient();
                    HttpRequest request = HttpRequest.newBuilder()
                            .uri(uri)
                            .GET()
                            .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    Random rand = new Random();
                    String apiResponse = response.body();
                    int randomNum = rand.nextInt((9));      
                    Random random = new Random();
                    JSONObject jsonResponse = new JSONObject(apiResponse);                    
                    JSONObject tracksObject = jsonResponse.getJSONObject("tracks");
                    JSONArray trackArray = tracksObject.getJSONArray("track");

                    int numTracks = trackArray.length();      
                    int randomIndex = random.nextInt(numTracks);

                
                    JSONObject randomTrack = trackArray.getJSONObject(randomIndex);
                    JSONArray imageArray = randomTrack.getJSONArray("image");
                    String mediumImageUrl = "";
                    for (int i = 0; i < imageArray.length(); i++) {
                        JSONObject imageObject = imageArray.getJSONObject(i);
                        if ("medium".equals(imageObject.getString("size"))) {
                            mediumImageUrl = imageObject.getString("#text");
                            break;
                        }
                    }

                    String trackName = randomTrack.getString("name");
                    String duration = randomTrack.getString("duration");
                    String mbid = randomTrack.getString("mbid");
                    String url = randomTrack.getString("url");
                    String artistName = randomTrack.getJSONObject("artist").getString("name");
                    String imageURL = mediumImageUrl;
                    
                    SearchResults res = new SearchResults(trackName, artistName, genre, imageURL, duration);
                    results.add(res);
                                                                                                   
                } catch (Exception e) {
                    e.printStackTrace();
                }
             
            } catch (Exception e) {
                e.printStackTrace();
            }
        }                                                            
     
       
        Map<String, String> formData = new HashMap<>();
        
        for(int i = 1; i <= 5; i++) {
        	String artistName = "artistName"+ i;
        	String trackName = "trackName"+ i;
        	String genreName = "genreName"+i;
        	String artworkURL = "artworkURL" + i;
        	
        	SearchResults e = results.get(i-1);
        	
        	formData.put(genreName, e.primaryGenreName);
        	formData.put(artistName, e.artistName);
        	formData.put(trackName, e.trackName);
        	formData.put(artworkURL, e.artworkURL);
        	
        }
        
    
        Gson gson = new Gson();
        String json = gson.toJson(formData);

   
        PrintWriter out = response1.getWriter();
        out.print(json);
        out.flush();
    }
}
