import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/getGenres")
public class getGenres extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");

        // Read the JSON data from the request body
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }

        // Parse the JSON data using Gso

        // Extract other parameters from the query string
        String username = request.getParameter("email");
        String password = request.getParameter("password");

        // Your business logic here...
        
        // Example: Print received data
        System.out.println("Received Username: " + username);
        System.out.println("Received Password: " + password);
        JsonObject jsonResponse = new JsonObject();
        
        
        String SQLurl = "jdbc:mysql://localhost:3306/audio-avenue";
        String SQLuser = "root";
        String SQLpassword = "Roadlesst1!";
        
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        try (
        		
        	Connection connection = DriverManager.getConnection(SQLurl, SQLuser, SQLpassword);
             PrintWriter out = response.getWriter()) {

            // Prepare SQL query
        	String sqlQuery = "SELECT Genre1, Genre2, Genre3, Genre4, Genre5 FROM UserTable WHERE UserName = ?";
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(1, username);

                // Execute the query and retrieve the results
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Retrieve genre values from the result set
                        String genre1 = resultSet.getString("Genre1");
                        String genre2 = resultSet.getString("Genre2");
                        String genre3 = resultSet.getString("Genre3");
                        String genre4 = resultSet.getString("Genre4");
                        String genre5 = resultSet.getString("Genre5");
                        
                        JSONObject genresObject = new JSONObject();
                        
                        Map<String, String> formData = new HashMap<>();
                        formData.put("Genre1", genre1);
                        formData.put("Genre2", genre2);
                    	formData.put("Genre3", genre3);
                    	formData.put("Genre4", genre4);
                    	formData.put("Genre5", genre5);
                    	 Gson gson = new Gson();
                         String json = gson.toJson(formData);

                        // Convert the JSONObject to a JSON string
                        

                        // Send the JSON string in the response
                        out.print(json);
                    } else {
                        // Handle the case where no results were found for the specified username
                        out.println("No genres found for username: " + username);
                    }
                }
            }
            catch (SQLException e) {
                out.println("Update execution failed! Error: " + e.getMessage());
            }

        } catch (SQLException e) {
            throw new ServletException("Connection failed! Error: " + e.getMessage());
        }
        
        
        
        

        // Example: Sending a response
        
       
    }
}