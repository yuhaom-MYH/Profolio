
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.*;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.io.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.util.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class SearchResults{
	String trackName;
	String artistName;
	String primaryGenreName;
	String artworkURL;
	String length;

	
	public SearchResults() {
		trackName = "";
		artistName = "";
		primaryGenreName = "";
		artworkURL = "";
		length = "";
	}
	
	public SearchResults(String trackname, String artist, String genre, String art, String len) {
		trackName = trackname;
		artistName = artist;
		primaryGenreName = genre;
		artworkURL = art;
		length = len;
	}
	
	
}