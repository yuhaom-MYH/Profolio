import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import java.net.InetSocketAddress;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class ChatboxServer extends WebSocketServer {
	public int num = 1;

    private Set<WebSocket> conns;

    public ChatboxServer(int port) {
        super(new InetSocketAddress(port));
        conns = Collections.synchronizedSet(new HashSet<>());
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        conns.add(conn);
        System.out.println("New connection from " + "0.0.0.0." + num);
        num ++;
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        conns.remove(conn);
        System.out.println("Closed connection to " +  "0.0.0.0." + num);
        num --;
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        String timeStamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
        String formattedMessage = "[" + timeStamp + "] " + message;
        System.out.println("Message from client: " +formattedMessage);
        for (WebSocket sock : conns) {
            sock.send(formattedMessage);
        }
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        ex.printStackTrace();
        if (conn != null) {
            conns.remove(conn);
            // do some thing if required
        }
    }

    @Override
    public void onStart() {
        System.out.println("Server started!");
        setConnectionLostTimeout(0);
        setConnectionLostTimeout(100);
    }

    public static void main(String[] args) {
        int port = 4567; // The port number should match with your frontend
        ChatboxServer server = new ChatboxServer(port);
        server.start();
    }
}

