
function getMusicRecommendations(genres) {
  let queryParams = genres.map((genre, index) => `genre${index + 1}=${encodeURIComponent(genre)}`).join('&');
  fetch(`/your-servlet-url?${queryParams}`)
    .then(response => response.json())
    .then(data => {
      // Now you can use this data to update the front-end.
      console.log(data);
      // For example, update the recommended songs list
      updateRecommendedSongs(data);
    })
    .catch(error => console.error('Error fetching music recommendations:', error));
}

function updateRecommendedSongs(recommendations) {
    // Assuming you have a container for the recommendations on your HTML
    const container = document.querySelector('.recommended-songs ul');
    container.innerHTML = ''; // Clear current recommendations
    Object.keys(recommendations).forEach(key => {
        if (key.startsWith('trackName')) {
            const li = document.createElement('li');
            li.textContent = recommendations[key];
            container.appendChild(li);
        }
    });
}

