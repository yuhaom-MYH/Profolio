/**
 * 
 */
function UserName(){
	window.location.href = 'UserNameChange.html';
}

function Password(){
	window.location.href = 'PasswordChange.html';
}

function Genre(){
	/* path to genre file */
}