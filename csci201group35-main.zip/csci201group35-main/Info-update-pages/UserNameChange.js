/**
 * 
 */
function UpdateUsername(){
	const username = document.getElementById('username').value;
    const confirmUsername = document.getElementById('confirm_username').value;
    
    if(username === '' || confirmUsername === ''){
		alert("Missing Required Information")
		return
	}
    
    
    if (username !== confirmUsername) {
		alert("Usernames do not match each other")
        return;
    }
   	console.log(username);
	console.log(confirmUsername);
    
    /* connect backend from here */
    /*
    
    
    
    
    
    
    */
    
}