/**
 * 
 */
function UpdatePassword(){
	const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    
    if(password === '' || confirmPassword === ''){
		alert("Missing Required Information")
		return
	}
    
    
    if (password !== confirmPassword) {
		alert("Passwords do not match each other")
        return;
    }
   	console.log(username);
	console.log(confirmUsername);
    
    /* connect backend from here */
    /*
    
    
    
    
    
    
    */
    
}